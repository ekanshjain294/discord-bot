import discord, io, random, chess
from discord.ext import commands
from PIL import Image, ImageDraw

# Active and pending games
ACTIVE_CHESS = {}
PENDING_CHESS = {}

# Path to your chess piece images
PIECE_PATH = r"C:\Users\Admin1\Downloads\discordbot_learn\chess_pieces"

def render_chess_png_bytes(board, last_move=None):
    """Render the chess board as PNG with pieces."""
    square_size = 80
    board_size = square_size * 8
    light, dark = (240, 217, 181), (181, 136, 99)

    img = Image.new("RGB", (board_size, board_size), "white")
    draw = ImageDraw.Draw(img)

    # Draw squares
    for r in range(8):
        for c in range(8):
            color = light if (r + c) % 2 == 0 else dark
            draw.rectangle(
                [c*square_size, r*square_size, (c+1)*square_size, (r+1)*square_size],
                fill=color
            )

    # Highlight last move
    if last_move:
        for sq in [last_move.from_square, last_move.to_square]:
            r, c = divmod(sq, 8)
            x0, y0 = c*square_size, (7-r)*square_size
            x1, y1 = x0+square_size, y0+square_size
            draw.rectangle([x0, y0, x1, y1], outline="red", width=3)

    # Place pieces
    piece_map = {
        "P": "wp.png", "N": "wn.png", "B": "wb.png", "R": "wr.png", "Q": "wq.png", "K": "wk.png",
        "p": "bp.png", "n": "bn.png", "b": "bb.png", "r": "br.png", "q": "bq.png", "k": "bk.png"
    }
    for sq, piece in board.piece_map().items():
        r, c = divmod(sq, 8)
        filename = piece_map.get(piece.symbol())
        if filename:
            piece_img = Image.open(f"{PIECE_PATH}\\{filename}").resize((square_size, square_size))
            img.paste(piece_img, (c*square_size, (7-r)*square_size), piece_img)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf

class ChessMatch:
    def __init__(self, channel_id, white_id, black_id):
        self.channel_id = channel_id
        self.white_id = white_id
        self.black_id = black_id
        self.board = chess.Board()
        self.last_move = None

class ChessCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def chess(self, ctx, opponent: discord.Member):
        """Challenge someone to chess."""
        cid = ctx.channel.id
        if cid in ACTIVE_CHESS:
            return await ctx.send("A chess game is already active here.")
        if opponent.bot or opponent.id == ctx.author.id:
            return await ctx.send("Invalid opponent.")
        PENDING_CHESS[cid] = ctx.author.id
        await ctx.send(f"{opponent.mention}, {ctx.author.mention} has challenged you to chess! Type `!accept` to accept.")

    @commands.command()
    async def accept(self, ctx):
        """Accept a pending chess challenge."""
        cid = ctx.channel.id
        if cid not in PENDING_CHESS:
            return await ctx.send("No pending challenge here.")
        challenger_id = PENDING_CHESS.pop(cid)
        if random.choice([True, False]):
            w, b = challenger_id, ctx.author.id
        else:
            w, b = ctx.author.id, challenger_id
        ACTIVE_CHESS[cid] = ChessMatch(cid, w, b)
        buf = render_chess_png_bytes(ACTIVE_CHESS[cid].board)
        await ctx.send(f"Game started! White: <@{w}> vs Black: <@{b}>", file=discord.File(buf, "chess.png"))

    @commands.command()
    async def move(self, ctx, mv: str):
        """Make a move in chess (use algebraic notation, e.g. e2e4)."""
        cid = ctx.channel.id
        if cid not in ACTIVE_CHESS:
            return await ctx.send("No active chess game here.")
        game = ACTIVE_CHESS[cid]
        player_id = ctx.author.id

        turn_color = chess.WHITE if game.board.turn == chess.WHITE else chess.BLACK
        if (turn_color == chess.WHITE and player_id != game.white_id) or (turn_color == chess.BLACK and player_id != game.black_id):
            return await ctx.send("Not your turn!")

        try:
            move = chess.Move.from_uci(mv)
        except:
            return await ctx.send("Invalid move format. Use like `e2e4`.")

        if move not in game.board.legal_moves:
            return await ctx.send("Illegal move.")

        game.board.push(move)
        game.last_move = move
        buf = render_chess_png_bytes(game.board, last_move=move)
        await ctx.send(file=discord.File(buf, "chess.png"))

        if game.board.is_game_over():
            result = game.board.result()
            ACTIVE_CHESS.pop(cid, None)
            await ctx.send(f"Game over! Result: {result}")

    @commands.command(name="chess_resign")
    async def chess_resign(self, ctx):
        """Resign from the current chess game."""
        cid = ctx.channel.id
        if cid not in ACTIVE_CHESS:
            return await ctx.send("No active chess game here.")

        game = ACTIVE_CHESS[cid]
        if ctx.author.id == game.white_id:
            winner = game.black_id
            msg = f"<@{ctx.author.id}> resigned. <@{winner}> wins!"
        elif ctx.author.id == game.black_id:
            winner = game.white_id
            msg = f"<@{ctx.author.id}> resigned. <@{winner}> wins!"
        else:
            return await ctx.send("You are not part of this game.")

        ACTIVE_CHESS.pop(cid, None)
        await ctx.send(msg)

async def setup(bot):
    await bot.add_cog(ChessCog(bot))
