import discord, io, random
from discord.ext import commands
import cairo

# Active games in memory
ACTIVE_C4 = {}

# --- Image Rendering for Connect 4 ---
def render_connect4_png_bytes(grid):
    size = 70
    cols, rows = 7, 6
    width, height = cols * size, rows * size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, width, height)
    ctx = cairo.Context(surface)

    # Background
    ctx.set_source_rgb(0.1, 0.3, 0.8)
    ctx.rectangle(0, 0, width, height)
    ctx.fill()

    # Draw cells
    for r in range(rows):
        for c in range(cols):
            x, y = c * size + size/2, r * size + size/2
            ctx.set_source_rgb(1, 1, 1)
            ctx.arc(x, y, size/2.5, 0, 6.28)
            ctx.fill()

            if grid[r][c] == "R":
                ctx.set_source_rgb(1, 0, 0)
                ctx.arc(x, y, size/3, 0, 6.28)
                ctx.fill()
            elif grid[r][c] == "Y":
                ctx.set_source_rgb(1, 1, 0)
                ctx.arc(x, y, size/3, 0, 6.28)
                ctx.fill()

    out = io.BytesIO()
    surface.write_to_png(out)
    out.seek(0)
    return out

# --- Game Logic ---
class Connect4Game:
    def __init__(self, channel_id, red_id, yellow_id):
        self.channel_id = channel_id
        self.red_id = red_id
        self.yellow_id = yellow_id
        self.grid = [[" "] * 7 for _ in range(6)]
        self.red_turn = True

    def drop(self, col):
        if col < 1 or col > 7: return False
        col -= 1
        for row in reversed(self.grid):
            if row[col] == " ":
                row[col] = "R" if self.red_turn else "Y"
                self.red_turn = not self.red_turn
                return True
        return False

    def winner(self):
        g = self.grid
        # Check rows
        for r in range(6):
            for c in range(4):
                if g[r][c] != " " and all(g[r][c+i] == g[r][c] for i in range(4)):
                    return g[r][c]
        # Check cols
        for c in range(7):
            for r in range(3):
                if g[r][c] != " " and all(g[r+i][c] == g[r][c] for i in range(4)):
                    return g[r][c]
        # Diagonals
        for r in range(3):
            for c in range(4):
                if g[r][c] != " " and all(g[r+i][c+i] == g[r][c] for i in range(4)):
                    return g[r][c]
        for r in range(3):
            for c in range(3, 7):
                if g[r][c] != " " and all(g[r+i][c-i] == g[r][c] for i in range(4)):
                    return g[r][c]
        # Draw
        if all(cell != " " for row in g for cell in row):
            return "D"
        return None

# --- Discord Cog ---
class Connect4Cog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def connect4(self, ctx, opponent: discord.Member):
        cid = ctx.channel.id
        if cid in ACTIVE_C4:
            return await ctx.send("Game already active here.")
        if opponent.bot or opponent.id == ctx.author.id:
            return await ctx.send("Invalid opponent.")

        r, y = (ctx.author.id, opponent.id) if random.choice([True, False]) else (opponent.id, ctx.author.id)
        ACTIVE_C4[cid] = Connect4Game(cid, r, y)

        await ctx.send(
            f"Connect 4 started! 🔴<@{r}> vs 🟡<@{y}>. Use `!c4_move <1-7>`",
            file=discord.File(render_connect4_png_bytes(ACTIVE_C4[cid].grid), "c4.png")
        )

    @commands.command(name="c4_move")
    async def c4_move_cmd(self, ctx, col: int):
        cid = ctx.channel.id
        if cid not in ACTIVE_C4:
            return await ctx.send("No game running here.")
        g = ACTIVE_C4[cid]
        cur = g.red_id if g.red_turn else g.yellow_id
        if ctx.author.id != cur:
            return await ctx.send("Not your turn.")
        if not g.drop(col):
            return await ctx.send("Invalid column.")

        await ctx.send(file=discord.File(render_connect4_png_bytes(g.grid), "c4.png"))
        w = g.winner()
        if w:
            if w == "D":
                await ctx.send("It's a draw!")
            else:
                winner = g.red_id if w == "R" else g.yellow_id
                await ctx.send(f"Winner: <@{winner}>")
            ACTIVE_C4.pop(cid)

async def setup(bot):
    await bot.add_cog(Connect4Cog(bot))
