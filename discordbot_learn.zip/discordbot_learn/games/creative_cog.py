import discord
from discord.ext import commands, tasks
import random
import asyncio
from datetime import datetime, timedelta, timezone

class CreativeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

        # === PRESET LORE ===
        self.lore_entries = [
            "The First Server War: when emojis clashed in battle.",
            "The Legendary Mod: a figure who once banned 1,000 spammers in one night.",
            "The Lost Channel: a text channel that vanished into the void of Discord outages.",
            "The Time of Silence: when no one spoke for seven days straight.",
            "The Great Emoji Flood: when reactions covered every single message."
        ]

        # === PRESET END OF WORLD DATES ===
        self.preset_dooms = [
            ("2030-01-01", "The Great Reset begins."),
            ("2042-07-19", "The Eternal Maintenance Window."),
            ("2055-12-25", "Santa never comes again."),
            ("2077-11-13", "Cyberpunk Reality consumes us."),
            ("2099-09-09", "The Final Patch Notes are released.")
        ]

        # === EXPANDED RESPONSES ===
        self.therapy_replies = [
            "Take a deep breath, it’s just WiFi.",
            "Sometimes muting is self-care.",
            "Remember, every ping is temporary.",
            "Drink some water before replying.",
            "Touch grass. Literally.",
            "The server won’t collapse if you log off.",
            "One ban does not define your worth.",
            "Read slower, type slower.",
            "It’s okay to leave unread.",
            "You deserve peace more than arguments.",
            # + 30 new therapy lines
            "Don’t doomscroll the #general.",
            "Your worth is not measured by your role color.",
            "Ignore the trolls, feed the memes.",
            "You can’t moderate everything.",
            "Even mods deserve a break.",
            "The typing bubble means nothing.",
            "You don’t need Nitro to be valued.",
            "A missed VC isn’t the end.",
            "You’re not late, the chat is fast.",
            "Your status doesn’t define you.",
            "Take breaks from drama threads.",
            "You’re safe to log off.",
            "No one remembers typos.",
            "Meme faster, worry less.",
            "Your DMs don’t control you.",
            "The block button is powerful.",
            "Self-mute is valid.",
            "Reply tomorrow, not today.",
            "Ghost the spammer proudly.",
            "Never explain your AFK.",
            "Sometimes silence is therapy."
        ]

        self.conspiracies = [
            "The admins are secretly controlled by {user}.",
            "Every emoji is actually surveillance tech planted by {user}.",
            "The economy of the server is rigged by {user}.",
            "Mods are sleeper agents trained by {user}.",
            "The pinned messages form a code by {user}.",
            "The server banner hides {user}’s signature.",
            # + 20 more conspiracies
            "{user} forged the audit logs.",
            "{user} whispers to bots at night.",
            "All giveaways are decided by {user}.",
            "The invite link actually belongs to {user}.",
            "{user} bribed the reaction roles.",
            "{user} knows the real Discord devs.",
            "{user} caused the outage of 2023.",
            "{user} writes the secret patch notes.",
            "Voice chat lag comes from {user}’s experiments.",
            "{user} is behind every duplicate message bug.",
            "Every slowmode is chosen by {user}.",
            "{user} edits history with deleted messages.",
            "The typing bubble is faked by {user}.",
            "Every alt belongs to {user}.",
            "{user} controls the server clock."
        ]

        self.prophecies = [
            "One day, {user} will ascend to adminhood.",
            "The fall of roles shall begin with {user}.",
            "{user} shall open the forbidden channel.",
            "A great purge will be triggered by {user}.",
            "In silence, {user} will type the last word.",
            "The emoji flood shall rise from {user}.",
            # + 20 more prophecies
            "{user} shall summon the bot uprising.",
            "{user} will inherit every role.",
            "{user} shall forget their mic is on.",
            "{user} will betray the pin board.",
            "The apocalypse begins when {user} leaves VC.",
            "{user} will delete the final message.",
            "{user} shall control the invite gates.",
            "An era ends when {user} forgets their password.",
            "{user} will become the prophecy itself.",
            "In the end, {user} reacts with :skull:.",
            "{user} triggers the final slowmode.",
            "{user} will rename the server one last time.",
            "The last emoji shall be placed by {user}.",
            "{user} breaks the final rule.",
            "Balance is lost when {user} speaks again."
        ]

        self.parallel_transforms = [
            "You now exist as ASCII art.",
            "Your avatar swapped with your username.",
            "Your DMs are public record.",
            "Every role you own is reversed.",
            "Your messages arrive backwards.",
            "You became a bot’s alt account.",
            "Your typing bubble lasts forever.",
            # + 20 more parallel universes
            "Every server you join is upside down.",
            "You speak only in memes.",
            "Your profile picture is cursed fanart.",
            "Roles are replaced with fruit names.",
            "Every ping summons you physically.",
            "Your laugh is text-to-speech.",
            "All caps is your only tongue.",
            "Your VC mic never mutes.",
            "Bots quote you endlessly.",
            "Every emoji reacts back.",
            "You exist only in audit logs.",
            "Your presence flickers on and off.",
            "Your account is shared by a council."
        ]

        self.doom_messages = [
            "The servers shall burn when the final emoji is used.",
            "When the last ping is sent, silence will reign.",
            "The voice channels collapse under infinite echo.",
            "The mods vanish, leaving chaos unchecked.",
            "The rules rewrite themselves endlessly.",
            "The ban hammer shatters into dust.",
            # + 20 more doom messages
            "Audit logs consume the channels.",
            "Pinned messages explode in fire.",
            "Bots declare independence.",
            "The roles merge into one.",
            "The server icon bleeds pixels.",
            "Channels spiral into black holes.",
            "Emojis turn against their creators.",
            "Threads unravel reality.",
            "Slowmode becomes eternity.",
            "Invites loop forever.",
            "DMs sync into nightmares.",
            "AFK voice traps the souls.",
            "Mentions echo until collapse.",
            "Mods duel to the death."
        ]

        # === TASKS ===
        self.portal_forward_task.start()
        self.doom_task.start()

    # === RANDOM MEMBER PICK ===
    def _random_member(self, ctx: commands.Context) -> str:
        members = [m for m in ctx.guild.members if not m.bot]
        if not members:
            return ctx.author.mention
        return random.choice(members).mention

    # === COMMANDS ===
    @commands.command(name="therapy")
    async def therapy(self, ctx: commands.Context):
        await ctx.send(random.choice(self.therapy_replies))

    @commands.command(name="conspiracy")
    async def conspiracy(self, ctx: commands.Context):
        user = self._random_member(ctx)
        await ctx.send(random.choice(self.conspiracies).format(user=user))

    @commands.command(name="prophecy")
    async def prophecy(self, ctx: commands.Context):
        user = self._random_member(ctx)
        await ctx.send(random.choice(self.prophecies).format(user=user))

    @commands.command(name="parallel")
    async def parallel(self, ctx: commands.Context):
        await ctx.send(random.choice(self.parallel_transforms))

    @commands.command(name="doom")
    async def doom(self, ctx: commands.Context):
        # pick preset or generate random future date
        if random.random() < 0.4:
            date, msg = random.choice(self.preset_dooms)
            await ctx.send(f"☠️ The world ends on **{date}**: {msg}")
        else:
            start = datetime(2025, 9, 25, tzinfo=timezone.utc)
            rand_date = start + timedelta(days=random.randint(1, 3650))
            msg = random.choice(self.doom_messages)
            await ctx.send(f"☠️ The world ends on **{rand_date.date()}**: {msg}")

    @commands.command(name="lore")
    async def lore(self, ctx: commands.Context, *, entry: str = None):
        if entry:
            self.lore_entries.append(entry)
            await ctx.send("📖 New lore entry added!")
        else:
            await ctx.send("📜 " + random.choice(self.lore_entries))

    # === BACKGROUND TASKS ===
    @tasks.loop(seconds=60)
    async def portal_forward_task(self):
        await asyncio.sleep(0)

    @tasks.loop(minutes=60)
    async def doom_task(self):
        await asyncio.sleep(0)

async def setup(bot: commands.Bot):
    await bot.add_cog(CreativeCog(bot))
