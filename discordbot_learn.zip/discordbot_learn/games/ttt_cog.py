import discord, io, random
from discord.ext import commands
import cairo

ACTIVE_TTT = {}  # channel_id -> game

# --- Image rendering for TicTacToe ---
def render_ttt_png_bytes(board):
    size = 100
    width, height = 3 * size, 3 * size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, width, height)
    ctx = cairo.Context(surface)

    # Background
    ctx.set_source_rgb(1, 1, 1)
    ctx.paint()

    # Grid lines
    ctx.set_source_rgb(0, 0, 0)
    ctx.set_line_width(5)
    for i in range(1, 3):
        ctx.move_to(i * size, 0)
        ctx.line_to(i * size, height)
        ctx.move_to(0, i * size)
        ctx.line_to(width, i * size)
    ctx.stroke()

    # Draw marks
    for r in range(3):
        for c in range(3):
            mark = board[r][c]
            x, y = c * size + size / 2, r * size + size / 2
            if mark == "X":
                ctx.set_source_rgb(1, 0, 0)
                ctx.set_line_width(8)
                ctx.move_to(x - 25, y - 25)
                ctx.line_to(x + 25, y + 25)
                ctx.move_to(x + 25, y - 25)
                ctx.line_to(x - 25, y + 25)
                ctx.stroke()
            elif mark == "O":
                ctx.set_source_rgb(0, 0, 1)
                ctx.set_line_width(8)
                ctx.arc(x, y, 30, 0, 6.28)
                ctx.stroke()

    out = io.BytesIO()
    surface.write_to_png(out)
    out.seek(0)
    return out


# --- Game logic ---
class TicTacToe:
    def __init__(self, channel_id, p1_id, p2_id):
        self.channel_id = channel_id
        self.p1_id = p1_id
        self.p2_id = p2_id
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.x_turn = True  # X always starts

    def move(self, r, c):
        if not (0 <= r < 3 and 0 <= c < 3):
            return False
        if self.board[r][c] != " ":
            return False
        self.board[r][c] = "X" if self.x_turn else "O"
        self.x_turn = not self.x_turn
        return True

    def winner(self):
        b = self.board
        # Rows/Cols
        for i in range(3):
            if b[i][0] != " " and b[i][0] == b[i][1] == b[i][2]:
                return b[i][0]
            if b[0][i] != " " and b[0][i] == b[1][i] == b[2][i]:
                return b[0][i]
        # Diagonals
        if b[0][0] != " " and b[0][0] == b[1][1] == b[2][2]:
            return b[0][0]
        if b[0][2] != " " and b[0][2] == b[1][1] == b[2][0]:
            return b[0][2]
        # Draw
        if all(cell != " " for row in b for cell in row):
            return "D"
        return None


# --- Discord Cog ---
class TicTacToeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ttt(self, ctx, opponent: discord.Member):
        cid = ctx.channel.id
        if cid in ACTIVE_TTT:
            return await ctx.send("A TicTacToe game is already running here.")
        if opponent.bot or opponent.id == ctx.author.id:
            return await ctx.send("Invalid opponent.")

        players = [ctx.author.id, opponent.id]
        random.shuffle(players)
        ACTIVE_TTT[cid] = TicTacToe(cid, players[0], players[1])

        await ctx.send(
            f"TicTacToe started! ❌ <@{players[0]}> vs ⭕ <@{players[1]}>. Use `!ttt_move row col`.",
            file=discord.File(render_ttt_png_bytes(ACTIVE_TTT[cid].board), "ttt.png")
        )

    @commands.command(name="ttt_move")
    async def ttt_move_cmd(self, ctx, row: int, col: int):
        cid = ctx.channel.id
        if cid not in ACTIVE_TTT:
            return await ctx.send("No TicTacToe game running here.")
        g = ACTIVE_TTT[cid]

        cur = g.p1_id if g.x_turn else g.p2_id
        if ctx.author.id != cur:
            return await ctx.send("It's not your turn.")

        if not g.move(row - 1, col - 1):
            return await ctx.send("Invalid move.")

        await ctx.send(file=discord.File(render_ttt_png_bytes(g.board), "ttt.png"))
        w = g.winner()
        if w:
            if w == "D":
                await ctx.send("It's a draw!")
            else:
                winner = g.p1_id if w == "X" else g.p2_id
                await ctx.send(f"Winner: <@{winner}>")
            ACTIVE_TTT.pop(cid)


async def setup(bot):
    await bot.add_cog(TicTacToeCog(bot))
