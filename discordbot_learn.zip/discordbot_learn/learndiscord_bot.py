from discord.ext import commands
import asyncio
import random
import json
from datetime import datetime, timedelta, timezone
import sys
import discord
from discord.ext import commands, tasks
import logging
from dotenv import load_dotenv
import os
import requests

OWNER_IDS = [798124367485206528, 835750053049925652]

load_dotenv()
token = os.getenv('DISCORD_TOKEN')

handler = logging.FileHandler(
    filename='discord.log', encoding='utf-8', mode='w')
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.presences = True
intents.guilds = True                 # Server info
intents.guild_messages = True         # Messages in guild channels
intents.guild_reactions = True        # Reactions in guild channels
intents.guild_typing = True           # Typing events in guild channels
intents.dm_messages = True            # Messages in DMs
intents.dm_reactions = True           # Reactions in DMs
intents.dm_typing = True              # Typing in DMs

bot = commands.Bot(command_prefix="!", intents=intents)

# remove default help command

bot.remove_command('help')

# bot events


@bot.event
async def on_member_join(member):
    await member.send(f'Welcome to the server, {member.name}!')

# Anything that checks and does something when a message is sent is here probably


@bot.event
async def on_message(message):
    if message.author.bot:  # ignore all bots, including self
        return

    if message.author.id in OWNER_IDS:
        await bot.process_commands(message)  # ignore owner
        return

    # Censor bad words
    bad_words = ['fuck', 'mkc', 'shit', 'bitch',
                 'bc', 'bsdk', 'fck off', 'fk off', 'fk',]
    if any(bad_word in message.content.lower() for bad_word in bad_words):  # case insensitive
        try:
            await message.delete()
            await message.channel.send(f'{message.author.mention}, that word is not allowed here!')
        except discord.Forbidden:
            print("I don't have permission to delete messages.")
        return

    # force commands to be lowercase
    if message.content.startswith('!'):
        parts = message.content.split(' ', 1)
        parts[0] = parts[0].lower()
        message.content = ' '.join(parts)

    # fIGURE out the end of the world
    endofworld = ['end of world']
    if any(endofworld in message.content.lower() for endofworld in endofworld):
        try:
            await message.channel.send(f'{message.author.mention}, The world will end on 31 December 2025 ')
        except Exception as e:
            print(f"Error sending end of world message: {e}")
        

    await bot.process_commands(message)

 # this is where on message ends


@bot.event
async def on_member_remove(member):
    channel = discord.utils.get(member.guild.text_channels, name='general')
    if channel:
        await channel.send(f'{member.name} has left the server.')


@bot.event
async def on_member_ban(guild, user):
    try:
        await user.send(f'You have been banned from {guild.name}.')
    except discord.Forbidden:
        # Can't send DM (user blocked bot or DMs disabled)
        print(f"Couldn't DM {user}.")


@bot.event
async def on_member_unban(guild, user):
    try:
        await user.send(f'You have been unbanned from {guild.name}.')
    except discord.Forbidden:
        print(f"Couldn't DM {user}.")


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send('Please provide all required arguments.')
    elif isinstance(error, commands.CommandNotFound):
        # Only respond if the message starts with prefix
        if ctx.message.content.startswith(bot.command_prefix):
            await ctx.send('This command does not exist.')
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send('You do not have the required permissions to use this command.')
    else:
        await ctx.send('An error occurred while processing the command.')
        raise error


@bot.event
async def on_disconnect():
    print("Bot has disconnected!")


@bot.event
async def on_resumed():
    print("Bot has resumed connection!")


# bot commands

#backup server command
@bot.command(name="backupserver", help="Backup the server structure (Owner only).")
async def backupserver(ctx):
    if ctx.author.id not in OWNER_IDS:
        return await ctx.send("❌ You do not have permission to use this command.")

    guild = ctx.guild

    backup_data = {
        "server_name": guild.name,
        "server_id": guild.id,
        "roles": [],
        "categories": [],
        "text_channels": [],
        "voice_channels": [],
    }

    # Backup roles
    for role in guild.roles:
        backup_data["roles"].append({
            "name": role.name,
            "permissions": role.permissions.value,
            "colour": role.color.value,
            "hoist": role.hoist,
            "mentionable": role.mentionable,
            "position": role.position,
        })

    # Backup categories
    for category in guild.categories:
        backup_data["categories"].append({
            "name": category.name,
            "position": category.position
        })

    # Backup text channels
    for channel in guild.text_channels:
        backup_data["text_channels"].append({
            "name": channel.name,
            "topic": channel.topic,
            "nsfw": channel.is_nsfw(),
            "position": channel.position,
            "category": channel.category.name if channel.category else None
        })

    # Backup voice channels
    for channel in guild.voice_channels:
        backup_data["voice_channels"].append({
            "name": channel.name,
            "bitrate": channel.bitrate,
            "user_limit": channel.user_limit,
            "position": channel.position,
            "category": channel.category.name if channel.category else None
        })

    # Save to JSON
    filename = f"{guild.name}_backup.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(backup_data, f, indent=4)

    await ctx.send(f"✅ Backup complete! Saved as `{filename}` (server structure only).")

#restore command

@bot.command(name="restoreserver", help="Restore a server from a backup JSON (Owner only).")
async def restoreserver(ctx, filename: str):
    if ctx.author.id not in OWNER_IDS:
        return await ctx.send("❌ You do not have permission to use this command.")

    try:
        with open(filename, "r", encoding="utf-8") as f:
            backup_data = json.load(f)
    except FileNotFoundError:
        return await ctx.send(f"❌ Backup file `{filename}` not found.")
    except json.JSONDecodeError:
        return await ctx.send("⚠️ Invalid JSON file.")

    guild = ctx.guild
    await ctx.send(f"🔄 Restoring server structure from `{filename}`...")

    # --- 1. Recreate Roles ---
    role_map = {}  # old role name -> new role object
    for role_data in sorted(backup_data["roles"], key=lambda r: r["position"]):
        if role_data["name"] == "@everyone":
            continue  # can't recreate @everyone
        new_role = await guild.create_role(
            name=role_data["name"],
            permissions=discord.Permissions(role_data["permissions"]),
            colour=discord.Colour(role_data["colour"]),
            hoist=role_data["hoist"],
            mentionable=role_data["mentionable"],
        )
        role_map[role_data["name"]] = new_role

    # --- 2. Recreate Categories ---
    category_map = {}
    for category_data in sorted(backup_data["categories"], key=lambda c: c["position"]):
        new_cat = await guild.create_category(
            name=category_data["name"],
            position=category_data["position"]
        )
        category_map[category_data["name"]] = new_cat

    # --- 3. Recreate Text Channels ---
    for channel_data in sorted(backup_data["text_channels"], key=lambda c: c["position"]):
        category = category_map.get(channel_data["category"])
        await guild.create_text_channel(
            name=channel_data["name"],
            topic=channel_data.get("topic"),
            nsfw=channel_data.get("nsfw", False),
            category=category,
            position=channel_data["position"]
        )

    # --- 4. Recreate Voice Channels ---
    for channel_data in sorted(backup_data["voice_channels"], key=lambda c: c["position"]):
        category = category_map.get(channel_data["category"])
        await guild.create_voice_channel(
            name=channel_data["name"],
            bitrate=channel_data.get("bitrate", 64000),
            user_limit=channel_data.get("user_limit", 0),
            category=category,
            position=channel_data["position"]
        )

    await ctx.send("✅ Server restore complete! (Roles, categories, and channels recreated.)")
    

# findgame command
@bot.command(name='findgame', help='Get a fitgirl-repack site link and search for the game urself')
async def Freegame(ctx, *, game_name: str):
    search_query = game_name.replace(' ', '+')
    url = f'https://fitgirl-repacks.site/?s={search_query}'
    await ctx.send(f'Here is the link to search for "{game_name}": {url}')


# afk command
@bot.command(name='afk', help='Set your status to AFK with an optional reason.')
async def afk(ctx, *, reason="No reason provided"):
    afk_role = discord.utils.get(ctx.guild.roles, name='afk')
    if not afk_role:
        afk_role = await ctx.guild.create_role(name='afk')
        for channel in ctx.guild.channels:
            await channel.set_permissions(afk_role, send_messages=False, speak=False)

    await ctx.author.add_roles(afk_role)
    await ctx.send(f'{ctx.author.mention} is now afk: {reason}')


# unafk command
@bot.command(name='unafk', help='Remove your AFK status.')
async def unafk(ctx):
    afk_role = discord.utils.get(ctx.guild.roles, name='afk')
    if afk_role in ctx.author.roles:
        await ctx.author.remove_roles(afk_role)
        await ctx.send(f'Welcome back, {ctx.author.mention}! You are no longer afk.')
    else:
        await ctx.send(f'{ctx.author.mention}, you are not marked as afk.')


# kick command
@bot.command(name='kick', help='Kick a member from the server. Usage: !kick @member [reason]')
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    try:
        await member.kick(reason=reason)
        await ctx.send(f'{member.mention} has been kicked from the server.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to kick this member.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')


# addrole command
@bot.command(name='addrole', help='Add a role to a member. Usage: !addrole @member RoleName')
@commands.has_permissions(manage_roles=True)
async def addrole(ctx, member: discord.Member, *, role_name):
    role = discord.utils.get(ctx.guild.roles, name=role_name)
    if not role:
        await ctx.send(f'Role "{role_name}" does not exist.')
        return
    try:
        await member.add_roles(role)
        await ctx.send(f'Role "{role_name}" has been added to {member.mention}.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to add this role.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')


# removerole command
@bot.command(name='removerole', help='Remove a role from a member. Usage: !removerole @member RoleName')
@commands.has_permissions(manage_roles=True)
async def removerole(ctx, member: discord.Member, *, role_name):
    role = discord.utils.get(ctx.guild.roles, name=role_name)
    if not role:
        await ctx.send(f'Role "{role_name}" does not exist.')
        return
    try:
        await member.remove_roles(role)
        await ctx.send(f'Role "{role_name}" has been removed from {member.mention}.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to remove this role.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')


# createrole command
@bot.command(name='createrole', help='Create a new role. Usage: !createrole RoleName')
@commands.has_permissions(manage_roles=True)
async def createrole(ctx, *, role_name):
    existing_role = discord.utils.get(ctx.guild.roles, name=role_name)
    if existing_role:
        await ctx.send(f'Role "{role_name}" already exists.')
        return
    try:
        await ctx.guild.create_role(name=role_name)
        await ctx.send(f'Role "{role_name}" has been created.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to create roles.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

# deleterole command


@bot.command(name='deleterole', help='Delete a role. Usage: !deleterole RoleName')
@commands.has_permissions(manage_roles=True)
async def deleterole(ctx, *, role_name):
    role = discord.utils.get(ctx.guild.roles, name=role_name)
    if not role:
        await ctx.send(f'Role "{role_name}" does not exist.')
        return
    try:
        await role.delete()
        await ctx.send(f'Role "{role_name}" has been deleted.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to delete this role.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

# ban command


@bot.command(name='ban', help='Ban a member from the server. Usage: !ban @member [reason]')
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    try:
        await member.ban(reason=reason)
        await ctx.send(f'{member.mention} has been banned from the server.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to ban this member.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

# unban command


@bot.command(name='unban', help='Unban a member from the server. Usage: !unban User#1234')
@commands.has_permissions(ban_members=True)
async def unban(ctx, *, member):
    banned_users = await ctx.guild.bans()
    member_name, member_discriminator = member.split('#')

    for ban_entry in banned_users:
        user = ban_entry.user
        if (user.name, user.discriminator) == (member_name, member_discriminator):
            try:
                await ctx.guild.unban(user)
                await ctx.send(f'{user.mention} has been unbanned from the server.')
                return
            except discord.Forbidden:
                await ctx.send("I don't have permission to unban this member.")
                return
            except Exception as e:
                await ctx.send(f'An error occurred: {str(e)}')
                return
    await ctx.send(f'User "{member}" not found in ban list.')

# mute command


@bot.command(name='mute', help='Mute a member. Usage: !mute @member [time in minutes] [reason]')
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, time: int = 10, *, reason=None):
    mute_role = discord.utils.get(ctx.guild.roles, name='Muted')
    if not mute_role:
        mute_role = await ctx.guild.create_role(name='Muted')
        for channel in ctx.guild.channels:
            await channel.set_permissions(mute_role, speak=False, send_messages=False, read_message_history=True, read_messages=True)

    try:
        await member.add_roles(mute_role)
        await ctx.send(f'{member.mention} has been muted for {time} minutes. Reason: {reason}')

        await asyncio.sleep(time * 60)  # Convert minutes to seconds
        await member.remove_roles(mute_role)
        await ctx.send(f'{member.mention} has been unmuted after serving their mute time.')
    except discord.Forbidden:
        await ctx.send("I don't have permission to mute this member.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

# unmute command


@bot.command(name='unmute', help='Unmute a member. Usage: !unmute @member')
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    mute_role = discord.utils.get(ctx.guild.roles, name='Muted')
    if mute_role in member.roles:
        try:
            await member.remove_roles(mute_role)
            await ctx.send(f'{member.mention} has been unmuted.')
        except discord.Forbidden:
            await ctx.send("I don't have permission to unmute this member.")
        except Exception as e:
            await ctx.send(f'An error occurred: {str(e)}')
    else:
        await ctx.send(f'{member.mention} is not muted.')

# purge command


@bot.command(name='purge', help='Purge messages in a channel. Usage: !purge [number of messages]')
@commands.has_permissions(manage_messages=True)
async def purge(ctx, number: int):
    if number < 1:
        await ctx.send('Please specify a number greater than 0.')
        return
    try:
        # +1 to include the command message
        deleted = await ctx.channel.purge(limit=number + 1)
        await ctx.send(f'Deleted {len(deleted)-1} messages.', delete_after=5)
    except discord.Forbidden:
        await ctx.send("I don't have permission to delete messages.")

# warn command


@bot.command(name='warn', help='Warn a member. Usage: !warn @member [reason]')
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    try:
        await member.send(f'You have been warned in {ctx.guild.name}. Reason: {reason}')
        await ctx.send(f'{member.mention} has been warned. Reason: {reason}')
    except discord.Forbidden:
        await ctx.send(f"Couldn't send a DM to {member.mention}, but they have been warned in the server.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

# meme command


@bot.command(name='meme', help='Fetch a random meme.')
async def meme(ctx):
    try:
        response = requests.get('https://meme-api.com/gimme')
        data = response.json()
        embed = discord.Embed(title=data['title'], url=data['postLink'])
        embed.set_image(url=data['url'])
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f'An error occurred while fetching a meme: {str(e)}')

# serverinfo command


@bot.command(name='serverinfo', help='Get information about the server.')
async def serverinfo(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=f"{guild.name} Server Information",
                          description=f"Information about {guild.name}", color=discord.Color.blue())
    embed.set_thumbnail(url=guild.icon.url if guild.icon else "")
    embed.add_field(name="Server Name", value=guild.name, inline=True)
    embed.add_field(name="Server ID", value=guild.id, inline=True)
    embed.add_field(name="Owner", value=str(guild.owner), inline=True)
    embed.add_field(name="Region", value=str(guild.region), inline=True)
    embed.add_field(name="Member Count", value=guild.member_count, inline=True)
    embed.add_field(name="Created At", value=guild.created_at.strftime(
        "%Y-%m-%d %H:%M:%S"), inline=True)
    embed.add_field(name="Roles", value=len(guild.roles), inline=True)
    embed.add_field(name="Channels", value=len(guild.channels), inline=True)
    await ctx.send(embed=embed)

# userinfo command


@bot.command(name='userinfo', help='Get information about a user. Usage: !userinfo @member')
async def userinfo(ctx, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(
        title=f"{member.name}'s Information", color=discord.Color.green())
    embed.set_thumbnail(url=member.avatar.url if member.avatar else "")
    embed.add_field(name="Username", value=str(member), inline=True)
    embed.add_field(name="User ID", value=member.id, inline=True)
    embed.add_field(name="Account Created", value=member.created_at.strftime(
        "%Y-%m-%d %H:%M:%S"), inline=True)
    embed.add_field(name="Joined Server", value=member.joined_at.strftime(
        "%Y-%m-%d %H:%M:%S"), inline=True)
    embed.add_field(name="Roles", value=", ".join(
        [role.name for role in member.roles if role.name != "@everyone"]), inline=False)
    embed.add_field(name="Status", value=str(
        member.status).title(), inline=True)
    await ctx.send(embed=embed)

# avatar command


@bot.command(name='avatar', help='Get the avatar of a user. Usage: !avatar @member')
async def avatar(ctx, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(
        title=f"{member.name}'s Avatar", color=discord.Color.purple())
    embed.set_image(url=member.avatar.url if member.avatar else "")
    await ctx.send(embed=embed)

# ping command


@bot.command(name='ping', help='Check the bot\'s latency.')
async def ping(ctx):
    latency = bot.latency * 1000  # Convert to milliseconds
    await ctx.send(f'Pong! Latency: {latency:.2f} ms')

# dm command


@bot.command(name='dm', help='Send a direct message to a user. Usage: !dm @member [message]')
async def dm(ctx, member: discord.Member, *, message: str):
    try:
        await member.send(message)
        await ctx.send(f'Message sent to {member.mention}.')
    except discord.Forbidden:
        await ctx.send(f"Couldn't send a DM to {member.mention}. They might have DMs disabled.")
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')
        


#hELP COMMAND RELATED or sum

class HelpView(discord.ui.View):
    def __init__(self, embeds):
        super().__init__(timeout=180)  # menu lasts 3 minutes
        self.embeds = embeds
        self.index = 0

    @discord.ui.button(label="⬅️ Prev", style=discord.ButtonStyle.secondary)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.index > 0:
            self.index -= 1
            await interaction.response.edit_message(embed=self.embeds[self.index], view=self)

    @discord.ui.button(label="➡️ Next", style=discord.ButtonStyle.secondary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.index < len(self.embeds) - 1:
            self.index += 1
            await interaction.response.edit_message(embed=self.embeds[self.index], view=self)


# --- Help Pagination ---

class HelpView(discord.ui.View):
    def __init__(self, embeds):
        super().__init__(timeout=180)  # 3 min timeout
        self.embeds = embeds
        self.index = 0

    @discord.ui.button(label="⬅️ Prev", style=discord.ButtonStyle.secondary)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.index > 0:
            self.index -= 1
            await interaction.response.edit_message(embed=self.embeds[self.index], view=self)

    @discord.ui.button(label="➡️ Next", style=discord.ButtonStyle.secondary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.index < len(self.embeds) - 1:
            self.index += 1
            await interaction.response.edit_message(embed=self.embeds[self.index], view=self)


# ---------------------------
# Categorized Help Command
# ---------------------------
@bot.command(name="help", help="Show categorized command list.")
async def help_command(ctx):
    categories = {
        "Games": [],
        "Moderation": [],
        "Owner": [],
        "Random": [],
        "Other": []
    }

    # Main file categorization
    moderation_cmds = [
        "kick", "ban", "unban", "mute", "unmute", "purge", "warn",
        "addrole", "removerole", "createrole", "deleterole"
    ]
    owner_cmds = ["shutdown", "restart", "backupserver", "restoreserver"]

    for cmd in bot.commands:
        if cmd.hidden:
            continue

        cog = cmd.cog
        if cog:
            # Check the module path of the cog to see if it is in 'games' folder
            module_name = cog.__module__  # e.g., games.ttt_cog
            if module_name.startswith("randomfun."):
                categories["Random"].append(f"`{cmd.name}`")
            elif module_name.startswith("games."):
                categories["Games"].append(f"`{cmd.name}`")
            else:
                categories["Other"].append(f"`{cmd.name}`")
        else:
            # Commands defined in main file
            if cmd.name.lower() in moderation_cmds:
                categories["Moderation"].append(f"`{cmd.name}`")
            elif cmd.name.lower() in owner_cmds:
                categories["Owner"].append(f"`{cmd.name}`")
            else:
                categories["Other"].append(f"`{cmd.name}`")

    # Create embed
    embed = discord.Embed(title="📘 Help - Command List",
                          color=discord.Color.blurple())

    for cat, cmds in categories.items():
        if cmds:
            embed.add_field(name=cat, value=", ".join(cmds), inline=False)

    embed.set_footer(text="Use !help <command> for details.")
    await ctx.send(embed=embed)

# reminder system

# File to save reminders
REMINDERS_FILE = "reminders.json"


def load_reminders():
    try:
        with open(REMINDERS_FILE, "r") as f:
            data = json.load(f)
            return [
                (uid, cid, msg, datetime.fromisoformat(t).astimezone(timezone.utc))
                for uid, cid, msg, t in data
            ]
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_reminders():
    with open(REMINDERS_FILE, "w") as f:
        json.dump(
            [(uid, cid, msg, t.isoformat()) for uid, cid, msg, t in REMINDERS],
            f
        )


REMINDERS = load_reminders()

# ------------------------------------
# Reminder Command
# ------------------------------------


@bot.command(
    name="remindme",
    help="Set a reminder. Usage: !remindme [timecode] [message]\nExamples: 10m, 2h, 1d, 2025-09-06T15:30"
)
async def remindme(ctx: commands.Context, timecode: str, *, message: str):
    now = datetime.now(timezone.utc)
    try:
        if timecode.endswith("m"):
            target = now + timedelta(minutes=int(timecode[:-1]))
        elif timecode.endswith("h"):
            target = now + timedelta(hours=int(timecode[:-1]))
        elif timecode.endswith("d"):
            target = now + timedelta(days=int(timecode[:-1]))
        else:
            # Allow ISO format e.g. 2025-09-06T15:30
            target = datetime.fromisoformat(timecode)
            if target.tzinfo is None:
                target = target.replace(tzinfo=timezone.utc)
            else:
                target = target.astimezone(timezone.utc)

        # Save reminder
        REMINDERS.append((ctx.author.id, ctx.channel.id, message, target))
        save_reminders()

        delta = target - now
        await ctx.send(f"⏰ Reminder set for {delta} from now ({target.isoformat()} UTC).")

        # If short reminder (<1h), handle with asyncio.sleep
        if delta.total_seconds() <= 3600:
            async def short_reminder():
                await asyncio.sleep(delta.total_seconds())
                try:
                    await ctx.author.send(f"⏰ Reminder: {message}")
                except discord.Forbidden:
                    await ctx.send(f"{ctx.author.mention} ⏰ Reminder: {message}")
                try:
                    REMINDERS.remove(
                        (ctx.author.id, ctx.channel.id, message, target))
                    save_reminders()
                except ValueError:
                    pass

            bot.loop.create_task(short_reminder())

    except Exception:
        await ctx.send("⚠️ Invalid time format. Use `10m`, `2h`, `1d`, or ISO (e.g. 2025-09-06T15:30).")

# ------------------------------------
# List Reminders
# ------------------------------------


@bot.command(name="reminders", help="List your active reminders.")
async def reminders_cmd(ctx):
    user_reminders = [(msg, t)
                      for uid, _, msg, t in REMINDERS if uid == ctx.author.id]
    if not user_reminders:
        await ctx.send("📭 You have no active reminders.")
    else:
        lines = [f"- {msg} at {t.isoformat()}" for msg, t in user_reminders]
        await ctx.send("📝 Your reminders:\n" + "\n".join(lines))

# ------------------------------------
# Cancel Reminder
# ------------------------------------


@bot.command(name="cancelreminder", help="Cancel one of your reminders. Usage: !cancelreminder [message]")
async def cancelreminder(ctx, *, message: str):
    for item in list(REMINDERS):
        uid, cid, msg, t = item
        if uid == ctx.author.id and msg.lower() == message.lower():
            REMINDERS.remove(item)
            save_reminders()
            await ctx.send(f"✅ Reminder '{message}' cancelled.")
            return
    await ctx.send("⚠️ No matching reminder found.")

# ------------------------------------
# Background Loop for Long Reminders
# ------------------------------------


@tasks.loop(seconds=30.0)
async def reminder_loop():
    now = datetime.now(timezone.utc)
    for item in list(REMINDERS):
        uid, cid, msg, t = item
        if t <= now:
            try:
                ch = bot.get_channel(cid)
                user = await bot.fetch_user(uid)
                if ch:
                    await ch.send(f"{user.mention} ⏰ Reminder: {msg}")
                else:
                    await user.send(f"⏰ Reminder: {msg}")
            except Exception:
                pass
            try:
                REMINDERS.remove(item)
                save_reminders()
            except Exception:
                pass


@bot.event
async def on_ready():
    if not reminder_loop.is_running():
        reminder_loop.start()
    print(f"✅ Your bot has started as {bot.user.name}")

# Owner commands

Owner_id = 798124367485206528


@bot.command(name='shutdown', help='Shut down the bot (Owner only).')
async def shutdown(ctx):
    if ctx.author.id != Owner_id:
        await ctx.send("You do not have permission to shut down the bot.")
        return
    await ctx.send("Shutting down...")
    await bot.close()


@bot.command(name='restart', help='Restart the bot (Owner only).')
async def restart(ctx):
    if ctx.author.id != Owner_id:
        await ctx.send("You do not have permission to restart the bot.")
        return
    await ctx.send("Restarting...")
    await bot.close()
    os.execv(sys.executable, [sys.executable] +
             [os.path.abspath(sys.argv[0])] + sys.argv[1:])


# ---------------------------
# Load cogs
# ---------------------------
async def load_cogs():
    cog_paths = [
        "games.connect4_cog",
        "games.chess_cog",
        "games.ttt_cog",
        "randomfun.creative_cog"
    ]
    for cog in cog_paths:
        try:
            await bot.load_extension(cog)
            print(f"✅ Loaded cog: {cog}")
        except Exception as e:
            print(f"❌ Failed to load cog {cog}: {e}")

# ---------------------------
# Main entrypoint
# ---------------------------


async def main():
    # Setup logging (only to discord.log, not console)
    logging.basicConfig(
        level=logging.INFO,
        handlers=[handler],   # ✅ Only file handler
        format="%(asctime)s:%(levelname)s:%(name)s: %(message)s"
    )

    async with bot:
        await load_cogs()
        await bot.start(token)

# ---------------------------
# Run bot
# ---------------------------
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("🛑 Bot shut down with Ctrl+C")


