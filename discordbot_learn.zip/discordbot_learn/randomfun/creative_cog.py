# creative_cog.py
from __future__ import annotations

import asyncio
import json
import os
import random
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence

import discord
from discord.ext import commands, tasks

# Attempt to import the Gemini client.
# NOTE: install the official gemini client (e.g. google-generativeai) and configure according to their docs.
# This file assumes a `genai` module with a simple generate() like API.
# If your installed library differs, adapt call_gemini_short() accordingly.
try:
    import google.generativeai as genai  # type: ignore
    GENAI_AVAILABLE = True
except Exception:
    # If import fails, still keep module importable; we'll raise helpful errors when generating.
    genai = None  # type: ignore
    GENAI_AVAILABLE = False

# -------------------------
# storage filenames & constants
# -------------------------
LORE_FILE = "preset_lore.json"
PORTAL_FILE = "portals.json"
DOOM_FILE = "doom.json"
LORE_INDEX_FILE = "lore_index.json"

# -------------------------
# types
# -------------------------
PortalMapping = Dict[int, int]  # source_channel_id -> dest_channel_id
LoreEntry = str

# -------------------------
# utilities
# -------------------------
def _now_utc() -> datetime:
    return datetime.now(timezone.utc)

def safe_load(path: str, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def safe_save(path: str, data) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        # if saving fails, just silently ignore in this cog (main bot should log)
        pass

def choose_random_member_mention(guild: discord.Guild, exclude_bots: bool = True) -> Optional[str]:
    # choose a random human member from the guild; return mention string like "<@id>"
    members = [m for m in guild.members if not (exclude_bots and m.bot)]
    if not members:
        return None
    chosen = random.choice(members)
    return chosen.mention

# -------------------------
# Gemini helper
# -------------------------
# This wrapper calls Gemini (via the genai module assumed above).
# It is intentionally conservative: it uses short safe prompts and extracts the text parts.
# It returns a short single-line string (trimmed) and never raises unexpected exceptions outward.
#
# IMPORTANT: adapt the internals of call_gemini_short to the exact client you installed.
# The code below uses the google.generativeai style usage (this may require adjustments).
#
# Requires env var GEMINI_API_KEY set.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

async def call_gemini_short(prompt: str, max_words: int = 28, model: str = "gpt-4o-mini"):  # model name placeholder
    """
    Call Gemini to generate a short text result.
    Returns a short safe string. If Gemini fails or returns nothing, a placeholder is returned.
    """
    # If no key or library, return placeholder that indicates misconfiguration.
    if not GENAI_AVAILABLE or not GEMINI_API_KEY:
        # Respect user's request for Gemini-only style; return a short placeholder rather than falling back to templates.
        return "Gemini is not configured."

    # Synchronous blocking work inside threadpool
    loop = asyncio.get_running_loop()

    def _blocking():
        try:
            # Initialize client if required
            # Example for google.generativeai usage:
            genai.configure(api_key=GEMINI_API_KEY)

            # The exact call depends on the installed client version.
            # We'll attempt to call the "generate_text" style interface and extract parts safely.
            response = genai.generate_text(
                model="gemini-1.5",  # adjust to available model if needed
                input=prompt,
                temperature=0.9,
                max_output_tokens=120,
            )

            # Try to extract text safely from likely response structures
            text_candidates = []

            # Common shape: response.text or response.output[0].content...
            if hasattr(response, "text") and isinstance(response.text, str):
                text_candidates.append(response.text)
            # Another shape
            if isinstance(response, dict):
                # try different keys
                for k in ("candidates", "outputs", "choices"):
                    if k in response and isinstance(response[k], (list, tuple)) and response[k]:
                        item = response[k][0]
                        # attempt to pull textual parts
                        if isinstance(item, dict):
                            for sub in ("content", "text", "message"):
                                v = item.get(sub)
                                if isinstance(v, str):
                                    text_candidates.append(v)
                        else:
                            if isinstance(item, str):
                                text_candidates.append(item)
            # Best-effort: join candidates
            text = ""
            if text_candidates:
                # pick the longest candidate
                text = max(text_candidates, key=len).strip()
            else:
                # try common attribute access for new SDKs
                if hasattr(response, "candidates"):
                    try:
                        cands = list(response.candidates)
                        if cands:
                            # content might be in .content, with .parts
                            cand = cands[0]
                            if hasattr(cand, "content"):
                                cont = getattr(cand, "content")
                                if hasattr(cont, "text"):
                                    text = cont.text.strip()
                                elif hasattr(cont, "parts"):
                                    parts = getattr(cont, "parts")
                                    text = " ".join(getattr(p, "text", "") for p in parts).strip()
                    except Exception:
                        text = ""

            # Final safety: ensure we have some non-empty text
            if not text:
                return "Gemini stayed silent."

            # Trim to max_words
            words = text.split()
            if len(words) > max_words:
                text = " ".join(words[:max_words]).rstrip(" ,.;:") + "..."
            # Ensure single-line, no newlines
            text = " ".join(text.splitlines()).strip()
            return text or "Gemini stayed silent."
        except Exception:
            # Always catch and return placeholder to avoid crashing.
            return "Gemini had a hiccup."
    return await loop.run_in_executor(None, _blocking)

# -------------------------
# The Creative Cog
# -------------------------
class CreativeCog(commands.Cog):
    """Creative features that heavily use Gemini for short playful outputs."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # portals mapping persisted to file
        self._portals: PortalMapping = safe_load(PORTAL_FILE, {})
        # doom date persisted
        doom_data = safe_load(DOOM_FILE, {})
        doom_date_str = doom_data.get("date")
        self._doom_date: Optional[datetime] = None
        if doom_date_str:
            try:
                self._doom_date = datetime.fromisoformat(doom_date_str)
                if self._doom_date.tzinfo is None:
                    self._doom_date = self._doom_date.replace(tzinfo=timezone.utc)
            except Exception:
                self._doom_date = None

        # lore: a list of 30 ordered lines (preset), persisted optionally to file
        self._lore: List[LoreEntry] = safe_load(LORE_FILE, [])
        if not self._lore:
            # Hardcoded 30 proper ordered lore lines: funny, cryptic, mystical style.
            self._lore = [
                "In the beginning, a sock was lost and the servers hummed brighter.",
                "When midnight pings gather, a single laugh will echo through the archives.",
                "A tiny avatar once blinked and time hiccuped for seven seconds.",
                "The Custodian of Emojis sleeps under the 'general' channel's floorboards.",
                "Three muted messages form a ladder to forgotten patch notes.",
                "When the dev forgets coffee, the bots briefly gain sentience and apologize.",
                "A thread that never ends holds the echo of yesterday's memes.",
                "The last unread DM contains a recipe for warm, improbable happiness.",
                "An old role named 'Archivist' knows where lost gifs go.",
                "When the server rejoices, a single notification turns into stardust.",
                "A mysterious rubber duck once debugged a logic loop with a squeak.",
                "The Keeper of Reactions hides a password inside a 404 gif.",
                "Whispers say the error logs sing lullabies on Sunday mornings.",
                "A patch note sealed an ancient joke that returns every leap year.",
                "The emoji 😳 is also a key in an alternate timezone.",
                "One forgotten command is the map that points to the Meme King.",
                "The archive remembers more secrets than any mod will admit.",
                "A gentle timestamp holds the scent of early alpha betas.",
                "At dawn a bot will apologize for every typo it ever made.",
                "The code once dreamed of being poetry and woke with a semicolon.",
                "An idle role still hums with the faint light of past servers.",
                "If you listen to the audit log, it sounds like waves on a keyboard.",
                "A hidden alias unlocks a channel that only appears in reflections.",
                "The first ping of the day decides the flavor of the next meme.",
                "Someone once typed 'brb' and a small cosmos paused politely.",
                "The Legend: a user typed without typos and the world paused politely.",
                "An old moderator's nickname became the name of a forgotten ritual.",
                "A single missed notification once saved a friendship from a typo.",
                "When all reactions align, a tiny portal to the archives opens.",
                "The server keeps a secret: kindness is the most permanent role."
            ]
            safe_save(LORE_FILE, self._lore)

        # index of next lore to reveal (persisted separately)
        self._lore_index: int = safe_load(LORE_INDEX_FILE, {"index": 0}).get("index", 0)
        if not isinstance(self._lore_index, int):
            self._lore_index = 0

        # start tasks
        # the tasks are defined below in the class as methods decorated with @tasks.loop,
        # so they become attributes on the class and can be started.
        try:
            # start periodic tasks if not already running
            if not hasattr(self, "doom_announcer_task"):
                # doom_announcer_task defined below, ensure it's bound
                pass
            self.doom_announcer_task.start()
            self.portal_housekeeping_task.start()
        except Exception:
            # If tasks cannot be started at cog init, ignore — they'll start on_ready if needed.
            pass

    # Save on unload
    def cog_unload(self) -> None:
        try:
            self.doom_announcer_task.cancel()
        except Exception:
            pass
        try:
            self.portal_housekeeping_task.cancel()
        except Exception:
            pass
        safe_save(PORTAL_FILE, self._portals)
        safe_save(LORE_FILE, self._lore)
        safe_save(DOOM_FILE, {"date": self._doom_date.isoformat() if self._doom_date else None})
        safe_save(LORE_INDEX_FILE, {"index": self._lore_index})

    # -------------------------
    # Portal management
    # -------------------------
    @commands.group(name="portal", invoke_without_command=True)
    async def portal(self, ctx: commands.Context) -> None:
        await ctx.send("Portal usage: `!portal random [minutes]` or `!portal manual <guild_id> <channel_id> [minutes]` or `!portal close` or `!portal list`")

    @portal.command(name="random")
    @commands.has_permissions(manage_guild=True)
    async def portal_random(self, ctx: commands.Context, minutes: Optional[int] = 10) -> None:
        """Open a portal to a random channel on another guild the bot can access."""
        src = ctx.channel
        candidates = []
        for g in self.bot.guilds:
            if g.id == ctx.guild.id:
                continue
            for ch in g.text_channels:
                if ch.permissions_for(g.me).send_messages:
                    candidates.append(ch)
        if not candidates:
            await ctx.send("No remote channels available.")
            return
        dest = random.choice(candidates)
        self._portals[src.id] = dest.id
        self._portals[dest.id] = src.id
        safe_save(PORTAL_FILE, self._portals)
        await ctx.send(f"Portal opened to {dest.mention} ({dest.guild.name}) for {minutes} minutes.")
        # schedule auto-close
        self.bot.loop.create_task(self._portal_auto_close(src.id, dest.id, max(60, minutes * 60)))

    @portal.command(name="manual")
    @commands.has_permissions(manage_guild=True)
    async def portal_manual(self, ctx: commands.Context, guild_id: int, channel_id: int, minutes: Optional[int] = 10) -> None:
        """Open a portal to specified guild_id and channel_id."""
        src = ctx.channel
        dest = self.bot.get_channel(channel_id)
        if not dest or not isinstance(dest, (discord.TextChannel, discord.Thread)):
            await ctx.send("Destination channel not found or not a text channel.")
            return
        # verify channel's guild matches guild_id
        if isinstance(dest, discord.TextChannel) and dest.guild.id != guild_id:
            await ctx.send("Destination channel doesn't belong to the specified guild.")
            return
        if not dest.permissions_for(dest.guild.me).send_messages:
            await ctx.send("I don't have permission to send messages in destination.")
            return
        self._portals[src.id] = dest.id
        self._portals[dest.id] = src.id
        safe_save(PORTAL_FILE, self._portals)
        await ctx.send(f"Manual portal opened to {dest.mention} ({dest.guild.name}) for {minutes} minutes.")
        self.bot.loop.create_task(self._portal_auto_close(src.id, dest.id, max(60, minutes * 60)))

    async def _portal_auto_close(self, src_id: int, dst_id: int, delay_seconds: int):
        await asyncio.sleep(delay_seconds)
        # check still exists
        if self._portals.get(src_id) == dst_id and self._portals.get(dst_id) == src_id:
            self._portals.pop(src_id, None)
            self._portals.pop(dst_id, None)
            safe_save(PORTAL_FILE, self._portals)
            s_ch = self.bot.get_channel(src_id)
            d_ch = self.bot.get_channel(dst_id)
            try:
                if isinstance(s_ch, (discord.TextChannel, discord.Thread)):
                    await s_ch.send("The portal has closed.")
                if isinstance(d_ch, (discord.TextChannel, discord.Thread)):
                    await d_ch.send("The portal has closed.")
            except Exception:
                pass

    @portal.command(name="close")
    @commands.has_permissions(manage_guild=True)
    async def portal_close(self, ctx: commands.Context) -> None:
        ch_id = ctx.channel.id
        partner = self._portals.get(ch_id)
        if not partner:
            await ctx.send("No portal to close here.")
            return
        self._portals.pop(ch_id, None)
        self._portals.pop(partner, None)
        safe_save(PORTAL_FILE, self._portals)
        await ctx.send("Portal closed.")
        pch = self.bot.get_channel(partner)
        try:
            if isinstance(pch, (discord.TextChannel, discord.Thread)):
                await pch.send("Partner portal closed.")
        except Exception:
            pass

    @portal.command(name="list")
    async def portal_list(self, ctx: commands.Context) -> None:
        if not self._portals:
            await ctx.send("No portals are active.")
            return
        seen = set()
        lines = []
        for a, b in self._portals.items():
            if (b, a) in seen or (a, b) in seen:
                continue
            seen.add((a, b))
            a_ch = self.bot.get_channel(a)
            b_ch = self.bot.get_channel(b)
            a_name = f"{a_ch.guild.name}#{a_ch.name}" if isinstance(a_ch, discord.TextChannel) else str(a)
            b_name = f"{b_ch.guild.name}#{b_ch.name}" if isinstance(b_ch, discord.TextChannel) else str(b)
            lines.append(f"{a_name} ↔ {b_name}")
        await ctx.send("Active portals:\n" + "\n".join(lines))

    @tasks.loop(seconds=60.0)
    async def portal_housekeeping_task(self):
        # simple tick to persist portals occasionally
        safe_save(PORTAL_FILE, self._portals)
        await asyncio.sleep(0)

    # Forward messages across portals: keep concise forwarding
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        # ignore bots
        if message.author.bot:
            return
        ch = message.channel
        if not isinstance(ch, (discord.TextChannel, discord.Thread)):
            # therapy DM handling and other features handled by separate listeners/commands
            return
        partner_id = self._portals.get(ch.id)
        if not partner_id:
            return
        dest = self.bot.get_channel(partner_id)
        if not dest or not isinstance(dest, (discord.TextChannel, discord.Thread)):
            return
        # construct small forwarded line
        author_display = message.author.display_name
        prefix = f"Forwarded from {ch.guild.name}#{ch.name} by {author_display}: "
        content = (message.content or "").strip()
        # include minimal attachment references
        if message.attachments:
            attach_texts = " ".join(a.url for a in message.attachments[:3])
            if content:
                content = content + " " + attach_texts
            else:
                content = attach_texts
        forward = (prefix + content).strip()
        # limit size
        if len(forward) > 1500:
            forward = forward[:1496] + "..."
        try:
            await dest.send(forward)
        except Exception:
            pass

    # -------------------------
    # Doom / apocalypse commands
    # -------------------------
    @commands.group(name="doom", invoke_without_command=True)
    async def doom(self, ctx: commands.Context) -> None:
        await ctx.send("doom subcommands: `!doom set YYYY-MM-DD`, `!doom random`, `!doom show`, `!doom clear`")

    @doom.command(name="set")
    @commands.has_permissions(manage_guild=True)
    async def doom_set(self, ctx: commands.Context, date_iso: str) -> None:
        dt = None
        try:
            dt = datetime.fromisoformat(date_iso)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        except Exception:
            await ctx.send("Invalid date format. Use ISO-like YYYY-MM-DD or full ISO.")
            return
        self._doom_date = dt
        safe_save(DOOM_FILE, {"date": self._doom_date.isoformat()})
        await ctx.send(f"Apocalypse set for {self._doom_date.date().isoformat()}.")

    @doom.command(name="random")
    @commands.has_permissions(manage_guild=True)
    async def doom_random(self, ctx: commands.Context, max_days: Optional[int] = 3650) -> None:
        # choose a random future date after today, within max_days
        max_days = int(max(30, min(36500, max_days)))
        days = random.randint(1, max_days)
        dt = _now_utc() + timedelta(days=days)
        self._doom_date = dt
        safe_save(DOOM_FILE, {"date": self._doom_date.isoformat()})
        # generate a short playful doom sentence via Gemini
        prompt = f"Invent a playful, silly apocalypse omen about the date {dt.date().isoformat()}. Keep it cryptic and under thirty words."
        text = await call_gemini_short(prompt, max_words=28)
        # ensure it's just the sentence (user requested no labels)
        await ctx.send(text)

    @doom.command(name="show")
    async def doom_show(self, ctx: commands.Context) -> None:
        if not self._doom_date:
            await ctx.send("No doom date set.")
            return
        now = _now_utc()
        delta = self._doom_date - now
        days = max(0, delta.days)
        hours = (delta.seconds // 3600)
        await ctx.send(f"{days} days, {hours} hours until the date set ({self._doom_date.date().isoformat()})")

    @doom.command(name="clear")
    @commands.has_permissions(manage_guild=True)
    async def doom_clear(self, ctx: commands.Context) -> None:
        self._doom_date = None
        safe_save(DOOM_FILE, {"date": None})
        await ctx.send("Doom cleared.")

    @tasks.loop(hours=1.0)
    async def doom_announcer_task(self):
        # Periodic check for doom approaching; posts playful messages when within thresholds
        if not self._doom_date:
            return
        now = _now_utc()
        if self._doom_date <= now:
            # announce once to a general channel if possible
            for g in self.bot.guilds:
                ch = discord.utils.get(g.text_channels, name="general") or next((c for c in g.text_channels if c.permissions_for(g.me).send_messages), None)
                if ch:
                    # send a short Gemini-generated final sentence or fallback
                    prompt = "Write one very short mystical final line (playful) under 20 words."
                    text = await call_gemini_short(prompt, max_words=20)
                    try:
                        await ch.send(text)
                    except Exception:
                        pass
            # clear doom date
            self._doom_date = None
            safe_save(DOOM_FILE, {"date": None})
            return
        # if within 3 days, post a short alert at many guilds
        remaining = self._doom_date - now
        if remaining <= timedelta(days=3):
            for g in self.bot.guilds:
                ch = discord.utils.get(g.text_channels, name="general") or next((c for c in g.text_channels if c.permissions_for(g.me).send_messages), None)
                if ch:
                    # create a playful short countdown via Gemini
                    date_str = self._doom_date.date().isoformat()
                    prompt = f"Short sly reminder: {remaining.days} days left until {date_str}. Make it cryptic, under 20 words."
                    text = await call_gemini_short(prompt, max_words=20)
                    try:
                        await ch.send(text)
                    except Exception:
                        pass

    # -------------------------
    # Conspiracy & Prophecy & related (Gemini-only output)
    # -------------------------
    async def _choose_random_server_member_mention(self, ctx: commands.Context) -> Optional[str]:
        if not ctx.guild:
            return None
        return choose_random_member_mention(ctx.guild)

    @commands.command(name="conspiracy", help="Generate a short silly conspiracy mentioning a random server user or a topic.")
    async def conspiracy(self, ctx: commands.Context, *, subject: Optional[str] = None) -> None:
        user_mention = await self._choose_random_server_member_mention(ctx)
        if subject:
            prompt = f"Write a playful silly conspiracy about {subject}. Keep it weird, cryptic and under 30 words."
        else:
            # include a random user
            if user_mention:
                # convert mention to display-friendly for Gemini prompt
                prompt = f"Write a playful silly conspiracy about {user_mention}. Keep it weird, cryptic and under 30 words."
            else:
                prompt = "Write a playful silly conspiracy about a mysterious server figure. Keep it weird, cryptic and under 30 words."
        text = await call_gemini_short(prompt, max_words=28)
        # ensure output is one sentence, and includes mention if we had one
        if user_mention and user_mention not in text:
            # append mention at the end to satisfy request to ping random user
            text = text.rstrip(" .!") + f" ({user_mention})"
        await ctx.send(text)

    @commands.command(name="prophecy", help="Generate a short prophecy mentioning a random server user or topic.")
    async def prophecy(self, ctx: commands.Context, *, topic: Optional[str] = None) -> None:
        # user examples provided earlier — we want prophecy lines like those.
        user_mention = await self._choose_random_server_member_mention(ctx)
        if topic:
            prompt = f"Write a short mystical prophecy about {topic}. Keep it cryptic, funny and under 30 words."
        else:
            if user_mention:
                prompt = f"Write a short mystical prophecy about {user_mention}. Keep it cryptic, funny and under 30 words."
            else:
                prompt = "Write a short mystical prophecy about a server figure. Keep it cryptic, funny and under 30 words."
        text = await call_gemini_short(prompt, max_words=28)
        if user_mention and user_mention not in text:
            text = text.rstrip(" .!") + f" ({user_mention})"
        await ctx.send(text)

    # -------------------------
    # omen / vision / curse / bless commands — short single lines via Gemini
    # -------------------------
    async def _gemini_single_line_for_user(self, mention: Optional[str], role: str) -> str:
        # role is like 'omen', 'vision', 'curse', 'bless'
        if mention:
            prompt = f"Write a short {role} about {mention}. Make it cryptic, playful, under 25 words."
        else:
            prompt = f"Write a short {role} for a mysterious server figure. Cryptic, playful, under 25 words."
        return await call_gemini_short(prompt, max_words=24)

    @commands.command(name="omen", help="Short playful omen mentioning a random user.")
    async def omen(self, ctx: commands.Context) -> None:
        mention = await self._choose_random_server_member_mention(ctx)
        text = await self._gemini_single_line_for_user(mention, "omen")
        if mention and mention not in text:
            text = text.rstrip(" .!") + f" ({mention})"
        await ctx.send(text)

    @commands.command(name="vision", help="Short playful vision about the server or a random user.")
    async def vision(self, ctx: commands.Context) -> None:
        mention = await self._choose_random_server_member_mention(ctx)
        text = await self._gemini_single_line_for_user(mention, "vision")
        if mention and mention not in text:
            text = text.rstrip(" .!") + f" ({mention})"
        await ctx.send(text)

    @commands.command(name="curse", help="A lighthearted playful 'curse' for a random user.")
    async def curse(self, ctx: commands.Context) -> None:
        mention = await self._choose_random_server_member_mention(ctx)
        text = await self._gemini_single_line_for_user(mention, "funny magical curse")
        if mention and mention not in text:
            text = text.rstrip(" .!") + f" ({mention})"
        await ctx.send(text)

    @commands.command(name="bless", help="A short playful blessing for a random user.")
    async def bless(self, ctx: commands.Context) -> None:
        mention = await self._choose_random_server_member_mention(ctx)
        text = await self._gemini_single_line_for_user(mention, "blessing")
        if mention and mention not in text:
            text = text.rstrip(" .!") + f" ({mention})"
        await ctx.send(text)

    # -------------------------
    # Parallel universe remix — takes last N messages and asks Gemini to rewrite them in parallel style
    # -------------------------
    @commands.command(name="parallel", help="Parallel-universe remix of recent messages. Usage: !parallel [count]")
    async def parallel(self, ctx: commands.Context, count: Optional[int] = 5) -> None:
        if not isinstance(ctx.channel, (discord.TextChannel, discord.Thread)):
            await ctx.send("Use this command in a text channel.")
            return
        count = max(1, min(20, int(count or 5)))
        msgs = []
        try:
            async for m in ctx.channel.history(limit=count + 5):
                if m.id == ctx.message.id:
                    continue
                if m.author.bot:
                    continue
                if not m.content:
                    continue
                msgs.append(f"{m.author.display_name}: {m.content}")
                if len(msgs) >= count:
                    break
        except Exception:
            await ctx.send("Couldn't read history.")
            return
        if not msgs:
            await ctx.send("No messages to remix.")
            return
        # build a short prompt with all messages
        # We will ask Gemini to produce a parallel-style line for each message, one sentence each.
        joined = "\n".join(msgs)
        prompt = f"Rewrite these lines in a strange parallel-universe style, one short sentence per line (playful, cryptic, under 20 words each):\n\n{joined}"
        result = await call_gemini_short(prompt, max_words=160)
        # It's possible Gemini will return multi-line. Send as-is.
        await ctx.send(result)

    # -------------------------
    # Lore system (ordered reveals)
    # -------------------------
    @commands.group(name="lore", invoke_without_command=True)
    async def lore(self, ctx: commands.Context) -> None:
        await ctx.send("Lore commands: `!lore reveal`, `!lore list`, `!lore index`")

    @lore.command(name="reveal")
    async def lore_reveal(self, ctx: commands.Context) -> None:
        # reveal next lore in order, plain text only (no labels)
        if self._lore_index >= len(self._lore):
            await ctx.send("No more lore to reveal.")
            return
        line = self._lore[self._lore_index]
        # increment index and persist
        self._lore_index += 1
        safe_save(LORE_INDEX_FILE, {"index": self._lore_index})
        await ctx.send(line)

    @lore.command(name="list")
    @commands.has_permissions(manage_guild=True)
    async def lore_list(self, ctx: commands.Context) -> None:
        # list all lore entries with their indices and whether revealed
        lines = []
        for idx, e in enumerate(self._lore):
            status = "revealed" if idx < self._lore_index else "locked"
            lines.append(f"{idx+1}. [{status}] {e}")
        # send in chunks to avoid message length limits
        out = "\n".join(lines)
        if len(out) > 1900:
            # split
            for i in range(0, len(out), 1900):
                await ctx.send(out[i:i+1900])
        else:
            await ctx.send(out)

    @lore.command(name="index")
    async def lore_index(self, ctx: commands.Context) -> None:
        await ctx.send(f"Next lore index: {self._lore_index + 1} of {len(self._lore)}")

    @lore.command(name="reset")
    @commands.has_permissions(manage_guild=True)
    async def lore_reset(self, ctx: commands.Context) -> None:
        self._lore_index = 0
        safe_save(LORE_INDEX_FILE, {"index": self._lore_index})
        await ctx.send("Lore index reset to start.")

    # -------------------------
    # Therapy — can be DM or server, uses Gemini for supportive one-liners.
    # It's non-clinical. For crisis words we respond with a safety message and encourage professional help.
    # -------------------------
    @commands.group(name="therapy", invoke_without_command=True)
    async def therapy(self, ctx: commands.Context) -> None:
        await ctx.send("Therapy: `!therapy start [dm|server]`, `!therapy stop`, `!therapy talk <text>`")

    # Keep a simple active sessions map: user_id -> {"mode":"dm"|"server"}
    _therapy_sessions: Dict[int, Dict[str, str]] = {}

    @therapy.command(name="start")
    async def therapy_start(self, ctx: commands.Context, mode: Optional[str] = "dm") -> None:
        mode = (mode or "dm").lower()
        if mode not in ("dm", "server"):
            await ctx.send("Mode must be 'dm' or 'server'.")
            return
        user = ctx.author
        if mode == "dm":
            try:
                await user.send("Therapy Hints: This is playful, non-clinical, mystical-tone support. Type `!therapy talk <text>` here.")
            except Exception:
                await ctx.send("Could not open DM. Please enable DMs.")
                return
            self._therapy_sessions[user.id] = {"mode": "dm"}
            await ctx.send("Therapy started in DMs. Check your messages.")
        else:
            # server mode: store session and respond in the channel for that user
            self._therapy_sessions[user.id] = {"mode": "server", "channel": ctx.channel.id}
            await ctx.send(f"Therapy started for {user.mention} in this channel. Use `!therapy talk <text>`.")

    @therapy.command(name="stop")
    async def therapy_stop(self, ctx: commands.Context) -> None:
        user = ctx.author
        if user.id in self._therapy_sessions:
            self._therapy_sessions.pop(user.id, None)
            try:
                await user.send("Your playful therapy session ended. Remember, I am not a replacement for professional help.")
            except Exception:
                pass
            await ctx.send("Therapy stopped.")
        else:
            await ctx.send("You don't have an active therapy session.")

    # A map of trigger words to curated responses (the bot chooses one randomly)
    CRISIS_KEYWORDS = {
        # words that indicate risk — respond with the safety message (not Gemini)
        "suicide": "If you're thinking about suicide or self-harm, please contact local emergency services or a suicide hotline immediately. You are not alone.",
        "kill myself": "If you're thinking about suicide or self-harm, please contact local emergency services or a suicide hotline immediately. You are not alone.",
        "i want to die": "If you're thinking about suicide or self-harm, please contact local emergency services or a suicide hotline immediately. You are not alone.",
        "harm": "If you're in immediate danger, call emergency services. For mental health help, contact a professional or hotline in your country.",
    }

    # curated tokenized responses per keyword for gentler replies (non-crisis but concerning)
    SUPPORT_KEYWORD_VARIANTS = {
        "sad": [
            "I'm sorry — that sounds heavy. Take one breath with me: in four, hold four, out four.",
            "That feeling matters. Is there one small thing that felt okay today?",
            "Sadness can be heavy. A tiny step: name one small win."
        ],
        "anxious": [
            "Anxiousness is noisy. Try a 30-second grounding: name five things you see.",
            "That's a lot to carry. Breathe slowly — in for four, out for four.",
            "When anxious, small controlled actions can help. Do one tiny thing now."
        ],
        "overwhelmed": [
            "Overwhelm is a big room. Which corner feels loudest right now?",
            "Small lists help: pick one thing to finish for a tiny win.",
            "Try splitting tasks into tiny bites for one minute each."
        ],
        "lonely": [
            "Loneliness hurts. Could you message one person 'thinking of you' and see what happens?",
            "You matter. Small steps: name three people who have made you smile.",
            "A short walk, or a song you like, can shift the edge of loneliness."
        ],
    }

    async def _therapy_handle_input(self, user: discord.User, text: str, channel: Optional[discord.abc.Messageable]):
        lower = text.lower()
        # Crisis check
        for k, msg in self.CRISIS_KEYWORDS.items():
            if k in lower:
                # immediate safety message (do not use Gemini for this)
                if channel:
                    await channel.send(msg)
                else:
                    try:
                        await user.send(msg)
                    except Exception:
                        pass
                return

        # check supportive keywords and use curated responses if matched
        for k, variants in self.SUPPORT_KEYWORD_VARIANTS.items():
            if k in lower:
                chosen = random.choice(variants)
                if channel:
                    await channel.send(chosen)
                else:
                    try:
                        await user.send(chosen)
                    except Exception:
                        pass
                return

        # otherwise use Gemini to produce a short supportive mystical line
        prompt = f"Playful mystical therapist: reply in one supportive sentence under 25 words to: \"{text}\""
        resp = await call_gemini_short(prompt, max_words=24)
        if channel:
            await channel.send(resp)
        else:
            try:
                await user.send(resp)
            except Exception:
                pass

    @therapy.command(name="talk")
    async def therapy_talk(self, ctx: commands.Context, *, text: str) -> None:
        user = ctx.author
        session = self._therapy_sessions.get(user.id)
        # Determine where to reply
        if session:
            if session.get("mode") == "dm":
                # ensure it's used in DM; if used in server, instruct to DM
                if not isinstance(ctx.channel, discord.DMChannel):
                    try:
                        await user.send("Please send `!therapy talk <text>` in DMs for your session.")
                    except Exception:
                        await ctx.send("Please DM the bot for therapy talk.")
                    return
                await self._therapy_handle_input(user, text, ctx.channel)
            else:
                # server mode — reply in the channel stored or current channel
                ch_id = session.get("channel") or ctx.channel.id
                ch = self.bot.get_channel(ch_id)
                if ch:
                    await self._therapy_handle_input(user, text, ch)
                else:
                    # fallback to DM if can't post in stored channel
                    await self._therapy_handle_input(user, text, ctx.channel)
        else:
            # no active session — open a short on-the-spot supportive reply (but notify user about sessions)
            await ctx.send("No active therapy session. Use `!therapy start dm` or `!therapy start server` to begin a session. Here's a short reply:")
            await self._therapy_handle_input(user, text, ctx.channel)

    # -------------------------
    # Misc small utilities (helpful commands)
    # -------------------------
    @commands.command(name="seed_gemini", help="(Admin) Ask Gemini to produce a single short creative nugget for testing")
    @commands.has_permissions(manage_guild=True)
    async def seed_gemini(self, ctx: commands.Context, *, prompt: str):
        text = await call_gemini_short(prompt, max_words=30)
        await ctx.send(text)

# -------------------------
# Cog setup for bot extension loading
# -------------------------
async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CreativeCog(bot))
